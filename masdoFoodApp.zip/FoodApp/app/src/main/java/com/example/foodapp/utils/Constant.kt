//package com.example.foodapp.utils
//
//
//object Constant {
//    const val DB_NAME = "food.db"
//    const val DATASTORE_NAME = "settings_datastore_preferences"
//    const val SETTINGS_KEY = "settings_key"
//}